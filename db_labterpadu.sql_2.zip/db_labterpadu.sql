-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Bulan Mei 2023 pada 21.32
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_labterpadu`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alat`
--

CREATE TABLE `alat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `lab_id` bigint(20) UNSIGNED NOT NULL,
  `total` int(11) NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `desc` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `alat`
--

INSERT INTO `alat` (`id`, `name`, `lab_id`, `total`, `color`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Kamera Sony', 5, 10, '#004cff', NULL, '2023-05-12 05:44:09', '2023-05-12 05:44:09'),
(2, 'Kamera Canon', 5, 10, '#ff0000', NULL, '2023-05-12 05:44:09', '2023-05-12 05:44:09'),
(3, 'Drone Mavic', 5, 4, '#ffea00', NULL, '2023-05-12 05:44:09', '2023-05-12 05:44:09'),
(4, 'Alat Gambar 1', 7, 7, '#ff0000', NULL, '2023-05-12 11:31:17', '2023-05-12 11:31:17'),
(5, 'Papan Gambar', 7, 10, '#1130ac', NULL, '2023-05-12 11:31:17', '2023-05-12 11:31:17'),
(6, 'Jangka Sorong', 7, 15, '#ff00a2', NULL, '2023-05-12 11:31:17', '2023-05-12 11:31:17'),
(7, 'Peta Gambar', 7, 5, '#5900ff', NULL, '2023-05-12 11:31:17', '2023-05-12 11:31:17');

-- --------------------------------------------------------

--
-- Struktur dari tabel `analisis`
--

CREATE TABLE `analisis` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `primary_id` varchar(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `ruangan_id` bigint(20) UNSIGNED NOT NULL,
  `alat_id` bigint(20) UNSIGNED NOT NULL,
  `total` int(11) NOT NULL,
  `event` varchar(30) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `desc` longtext DEFAULT NULL,
  `berkas` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `lab`
--

CREATE TABLE `lab` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `desc` longtext DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `lab`
--

INSERT INTO `lab` (`id`, `name`, `desc`, `photo`, `created_at`, `updated_at`) VALUES
(1, 'Biologi', 'Laboratorium Biologi Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(2, 'Data Intelligence', 'Laboratorium Data Intelligence Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(3, 'Instrumen dan Kalibrasi', 'Laboratorium Kimia Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(4, 'Kimia', 'Laboratorium Kimia Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(5, 'Multimedia Dan Komunikasi', 'Laboratorium Multimedia Dan Komunikasi Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(6, 'Penyelenggaraan Informasi Geospasial', 'Laboratorium Penyelenggaraan Informasi Geospasial Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(7, 'Studio Gambar', 'Laboratorium Studio Gambar Lab Terpadu', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_100000_create_password_resets_table', 1),
(2, '2019_08_19_000000_create_failed_jobs_table', 1),
(3, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(4, '2022_12_24_142236_lab', 1),
(5, '2022_12_29_080447_ruangan', 1),
(6, '2023_01_01_100459_p_ruangan', 1),
(7, '2023_01_15_081610_alat', 1),
(8, '2023_01_15_082404_p_alat', 1),
(9, '2023_01_22_111945_temp_berkas', 1),
(10, '2023_05_03_104800_create_analisis_table', 1),
(11, 'users_table', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `p_alat`
--

CREATE TABLE `p_alat` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `primary_id` varchar(50) NOT NULL,
  `name` varchar(30) NOT NULL,
  `alat_id` bigint(20) UNSIGNED NOT NULL,
  `total` int(11) NOT NULL,
  `event` varchar(30) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `desc` longtext DEFAULT NULL,
  `berkas` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `p_alat`
--

INSERT INTO `p_alat` (`id`, `primary_id`, `name`, `alat_id`, `total`, `event`, `date_start`, `date_end`, `time_start`, `time_end`, `desc`, `berkas`, `created_at`, `updated_at`) VALUES
(1, 'K/A-PA-1', 'Amirull Azmi', 2, 4, 'Penelitian', '2023-05-12', '2023-05-14', '20:45:00', '23:49:00', NULL, NULL, '2023-05-12 05:45:23', '2023-05-12 05:45:23'),
(2, 'K/A-PA-1', 'Amirull Azmi', 1, 3, 'Penelitian', '2023-05-12', '2023-05-14', '20:45:00', '23:49:00', NULL, NULL, '2023-05-12 05:45:23', '2023-05-12 05:45:23'),
(3, 'K/A-PA-1', 'Amirull Azmi', 3, 1, 'Penelitian', '2023-05-12', '2023-05-14', '20:45:00', '23:49:00', NULL, NULL, '2023-05-12 05:45:23', '2023-05-12 05:45:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `p_ruangan`
--

CREATE TABLE `p_ruangan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `ruangan_id` bigint(20) UNSIGNED NOT NULL,
  `event` varchar(30) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `desc` longtext DEFAULT NULL,
  `berkas` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `p_ruangan`
--

INSERT INTO `p_ruangan` (`id`, `name`, `ruangan_id`, `event`, `date_start`, `date_end`, `time_start`, `time_end`, `desc`, `berkas`, `created_at`, `updated_at`) VALUES
(1, 'Amirull Azmi', 2, 'Mengajar', '2023-05-12', '2023-05-14', '00:00:00', '15:08:00', NULL, NULL, '2023-05-12 05:03:15', '2023-05-12 05:03:15'),
(2, 'Kusmayuda', 4, 'Praktikum', '2023-05-23', '2023-05-26', '21:05:00', '01:09:00', NULL, NULL, '2023-05-12 05:03:53', '2023-05-12 05:03:53'),
(3, 'Farhan', 5, 'Praktikum', '2023-05-14', '2023-05-16', '00:09:00', '16:10:00', NULL, NULL, '2023-05-12 05:04:20', '2023-05-12 05:04:20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ruangan`
--

CREATE TABLE `ruangan` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) DEFAULT NULL,
  `desc` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ruangan`
--

INSERT INTO `ruangan` (`id`, `name`, `color`, `desc`, `created_at`, `updated_at`) VALUES
(1, 'Aula', 'yellow', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(2, 'LPIG', '#ff0000', NULL, '2023-05-12 05:02:20', '2023-05-12 05:02:20'),
(3, 'Ruang Gambar', '#00c6e0', NULL, '2023-05-12 05:02:20', '2023-05-12 05:02:29'),
(4, 'Lab Komputer', '#ff00dd', NULL, '2023-05-12 05:02:20', '2023-05-12 05:02:20'),
(5, 'Lab Biologi', '#39bd00', NULL, '2023-05-12 05:02:20', '2023-05-12 05:02:20'),
(6, 'Lab Kimia', '#2500db', NULL, '2023-05-12 05:02:20', '2023-05-12 05:02:20'),
(7, 'Ruang Gambar 2', '#e00000', NULL, '2023-05-12 05:21:33', '2023-05-12 05:21:33'),
(8, 'Ruang Gambar 3', '#00c2b5', NULL, '2023-05-12 05:21:33', '2023-05-12 05:21:33'),
(9, 'Aula 2', '#c800ff', NULL, '2023-05-12 05:21:33', '2023-05-12 05:21:33'),
(10, 'Aula 3', '#1eb300', NULL, '2023-05-12 05:21:33', '2023-05-12 05:21:33'),
(11, 'Ruang Baca', '#c1cef5', NULL, '2023-05-12 05:21:33', '2023-05-12 05:21:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `temp_berkas`
--

CREATE TABLE `temp_berkas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `berkas` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `temp_berkas`
--

INSERT INTO `temp_berkas` (`id`, `name`, `berkas`, `created_at`, `updated_at`) VALUES
(1, 'Peminjaman Ruangan', '', '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(2, 'Peminjaman Alat', '', '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(3, 'Analisis', NULL, '2023-05-12 06:26:05', '2023-05-12 06:26:05'),
(4, 'SK ALAT', NULL, '2023-05-12 06:26:23', '2023-05-12 06:26:23'),
(5, 'SK Ruangan', NULL, '2023-05-12 06:26:33', '2023-05-12 06:26:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(255) NOT NULL,
  `lab_id` bigint(20) UNSIGNED DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `email`, `name`, `email_verified_at`, `password`, `level`, `lab_id`, `address`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'superadmin@gmail.com', 'Admin Lab Terpadu', NULL, '$2y$10$DhCMR1YY.44kW6hkuzLc2.1yGmv0H5FAqMRON1Aa2iwuo/BRB3zHW', '0', 1, '', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(2, 'admin@gmail.com', 'Dummy Laboran', NULL, '$2y$10$OHabEGUEKUnjrC3RMU6MleLJDRy51bsDr6y/bke07KuVlcxW9Yu1.', '1', 7, 'ini alamat laboran', NULL, '2023-05-12 05:00:19', '2023-05-12 05:00:19'),
(3, 'amirull@gmail.com', 'Amirull Azmi', NULL, '$2y$10$n07jeaxzSpGOka.h5GPN1.LtnLd1LS6jHgL3NnSnLOns1B3V/z4yu', '1', 5, NULL, NULL, '2023-05-12 05:10:26', '2023-05-12 05:10:26');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alat`
--
ALTER TABLE `alat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `alat_lab_id_foreign` (`lab_id`);

--
-- Indeks untuk tabel `analisis`
--
ALTER TABLE `analisis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `analisis_ruangan_id_foreign` (`ruangan_id`),
  ADD KEY `analisis_alat_id_foreign` (`alat_id`);

--
-- Indeks untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indeks untuk tabel `lab`
--
ALTER TABLE `lab`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indeks untuk tabel `p_alat`
--
ALTER TABLE `p_alat`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_alat_alat_id_foreign` (`alat_id`);

--
-- Indeks untuk tabel `p_ruangan`
--
ALTER TABLE `p_ruangan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p_ruangan_ruangan_id_foreign` (`ruangan_id`);

--
-- Indeks untuk tabel `ruangan`
--
ALTER TABLE `ruangan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `temp_berkas`
--
ALTER TABLE `temp_berkas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `temp_berkas_name_unique` (`name`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `alat`
--
ALTER TABLE `alat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `analisis`
--
ALTER TABLE `analisis`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `lab`
--
ALTER TABLE `lab`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `p_alat`
--
ALTER TABLE `p_alat`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `p_ruangan`
--
ALTER TABLE `p_ruangan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `ruangan`
--
ALTER TABLE `ruangan`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `temp_berkas`
--
ALTER TABLE `temp_berkas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `alat`
--
ALTER TABLE `alat`
  ADD CONSTRAINT `alat_lab_id_foreign` FOREIGN KEY (`lab_id`) REFERENCES `lab` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `analisis`
--
ALTER TABLE `analisis`
  ADD CONSTRAINT `analisis_alat_id_foreign` FOREIGN KEY (`alat_id`) REFERENCES `alat` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `analisis_ruangan_id_foreign` FOREIGN KEY (`ruangan_id`) REFERENCES `ruangan` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `p_alat`
--
ALTER TABLE `p_alat`
  ADD CONSTRAINT `p_alat_alat_id_foreign` FOREIGN KEY (`alat_id`) REFERENCES `alat` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `p_ruangan`
--
ALTER TABLE `p_ruangan`
  ADD CONSTRAINT `p_ruangan_ruangan_id_foreign` FOREIGN KEY (`ruangan_id`) REFERENCES `ruangan` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
