const Tron = () => {
    return (
        <>
            <div className="tron-admin"></div>
        </>
    )
}
export default Tron